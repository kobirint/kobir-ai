import Link from "next/link";
export default function Header(){
 return <header className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-slate-950/70 backdrop-blur">
   <Link href="/" className="font-bold text-lg">پەیمانگای کۆبیر</Link>
   <Link href="/admin/login" className="text-xs text-slate-400 hover:text-white">Admin</Link>
 </header>
}