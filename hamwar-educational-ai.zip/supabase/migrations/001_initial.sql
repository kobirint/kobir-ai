create extension if not exists pgcrypto;

create table if not exists public.access_codes (
 id uuid primary key default gen_random_uuid(),
 code_hash text unique not null,
 code_last4 text not null,
 is_active boolean not null default true,
 used boolean not null default false,
 created_at timestamptz not null default now(),
 activated_at timestamptz
);

create table if not exists public.students (
 id uuid primary key default gen_random_uuid(),
 access_code_id uuid unique references public.access_codes(id) on delete restrict,
 full_name text not null,
 grade text not null check (grade in ('پۆلی ٩','پۆلی ١٠','پۆلی ١١','پۆلی ١٢')),
 city text not null,
 school text not null,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
 id uuid primary key default gen_random_uuid(),
 student_id uuid references public.students(id) on delete cascade,
 role text not null check (role in ('user','assistant')),
 content text not null,
 created_at timestamptz not null default now()
);

alter table public.access_codes enable row level security;
alter table public.students enable row level security;
alter table public.chat_messages enable row level security;

-- All sensitive reads/writes are performed server-side with the Supabase secret key.
-- Do not expose the secret key to the browser.
