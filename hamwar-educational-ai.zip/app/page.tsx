import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Home(){
 return <div className="min-h-screen gradient flex flex-col">
  <Header/>
  <main className="flex-1 flex items-center justify-center px-5 py-16">
   <div className="w-full max-w-3xl text-center">
    <div className="inline-flex rounded-full border border-blue-400/20 bg-blue-400/10 px-4 py-2 text-sm text-blue-200 mb-6">سیستەمی خوێندنگەیی زیرەک</div>
    <h1 className="text-4xl md:text-6xl font-black leading-tight mb-5">یارمەتیدەری خوێندنگەیی<br/>بۆ قوتابیانی کوردستان</h1>
    <p className="text-slate-300 max-w-xl mx-auto mb-9">پرسیارەکەت بنووسە یان ڕەسمی پرسیارەکەت بنێرە و وەڵامی هەنگاو بە هەنگاو وەربگرە.</p>
    <Link href="/student/login" className="inline-flex rounded-2xl bg-blue-600 hover:bg-blue-500 px-8 py-4 font-bold shadow-lg shadow-blue-900/30">چوونە ژوورەوەی قوتابی</Link>
    <div className="mt-7 text-sm text-slate-500">سپۆنسەرکراو لەلایەن <b className="text-slate-300">پەیمانگای کۆبیر</b></div>
   </div>
  </main><Footer/>
 </div>
}