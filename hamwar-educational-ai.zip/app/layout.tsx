import "./globals.css";
import { ReactNode } from "react";

export const metadata = {
  title: "پەیمانگای کۆبیر | هەموار جۆڵا",
  description: "سیستەمی خوێندنگەیی زیرەک",
};

export default function RootLayout({children}:{children:ReactNode}) {
  return <html lang="ku" dir="rtl"><body>{children}</body></html>;
}