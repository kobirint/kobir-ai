 "use client";
import {useEffect,useRef,useState} from "react"; import {useRouter} from "next/navigation";
import Header from "@/components/Header"; import Footer from "@/components/Footer";
type Msg={role:"user"|"assistant",content:string};
export default function Chat(){
 const [msgs,setMsgs]=useState<Msg[]>([]),[text,setText]=useState(""),[image,setImage]=useState<File|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(""); const bottom=useRef<HTMLDivElement>(null); const router=useRouter();
 useEffect(()=>{fetch("/api/student/profile").then(r=>{if(!r.ok)router.replace("/student/login")})},[router]);
 useEffect(()=>bottom.current?.scrollIntoView({behavior:"smooth"}),[msgs,busy]);
 async function send(e?:React.FormEvent){e?.preventDefault(); if(!text.trim()&&!image)return; setBusy(true);setError("");
  const fd=new FormData();fd.append("message",text);if(image)fd.append("image",image);
  setMsgs(m=>[...m,{role:"user",content:text||(image?"📷 ڕەسمی پرسیار":"")}]);setText("");setImage(null);
  const r=await fetch("/api/ai/chat",{method:"POST",body:fd});const d=await r.json();setBusy(false);
  if(!r.ok){setError(d.error||"کێشەیەک ڕوویدا");return}setMsgs(m=>[...m,{role:"assistant",content:d.answer}]);
 }
 return <div className="min-h-screen gradient flex flex-col"><Header/><main className="flex-1 max-w-4xl w-full mx-auto p-4 flex flex-col">
  <div className="flex-1 space-y-4 py-5">{msgs.length===0&&<div className="text-center py-20"><h1 className="text-3xl font-bold">بەخێربێیت 👋</h1><p className="text-slate-400 mt-2">پرسیارێکی خوێندنگەیی بنووسە.</p></div>}
  {msgs.map((m,i)=><div key={i} className={m.role==="user"?"flex justify-start":"flex justify-end"}><div className={"max-w-[85%] rounded-2xl px-4 py-3 whitespace-pre-wrap "+(m.role==="user"?"bg-blue-600":"glass")}>{m.content}</div></div>)}{busy&&<div className="text-slate-400">لە وەڵامدانەوەدایە...</div>}<div ref={bottom}/></div>
  {error&&<p className="text-red-300 text-sm mb-2">{error}</p>}
  <form onSubmit={send} className="glass rounded-2xl p-3 flex items-end gap-2"><label className="rounded-xl bg-white/5 px-3 py-3 cursor-pointer" title="ڕەسمی پرسیار">📎<input type="file" accept="image/*" className="hidden" onChange={e=>setImage(e.target.files?.[0]||null)}/></label>
   <textarea value={text} onChange={e=>setText(e.target.value)} placeholder={image?`ڕەسم هەڵبژێردراوە: ${image.name}`:"پرسیارەکەت بنووسە..."} className="flex-1 bg-transparent outline-none resize-none min-h-12 max-h-40 py-3" onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}}/>
   <button disabled={busy} className="rounded-xl bg-blue-600 px-5 py-3 font-bold disabled:opacity-50">ناردن</button>
  </form></main><Footer/></div>
}