 "use client";
import {useState} from "react"; import {useRouter} from "next/navigation";
import Header from "@/components/Header"; import Footer from "@/components/Footer";
export default function Onboarding(){
 const [form,setForm]=useState({full_name:"",grade:"پۆلی ٩",city:"",school:""}); const [error,setError]=useState(""); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault(); const r=await fetch("/api/student/profile",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); const d=await r.json(); if(!r.ok){setError(d.error);return} router.push("/student/chat");}
 return <div className="min-h-screen gradient flex flex-col"><Header/><main className="flex-1 flex items-center justify-center p-5"><form onSubmit={submit} className="glass rounded-3xl p-7 w-full max-w-lg space-y-4">
 <h1 className="text-2xl font-bold">زانیاری قوتابی</h1><p className="text-slate-400">تەنها یەک جار پڕی بکەرەوە.</p>
 {([["full_name","ناوی سیانی"],["city","شار"],["school","قوتابخانە"]] as const).map(([k,l])=><input key={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} placeholder={l} className="w-full rounded-xl bg-slate-950 border border-white/10 px-4 py-3" required/>)}
 <select value={form.grade} onChange={e=>setForm({...form,grade:e.target.value})} className="w-full rounded-xl bg-slate-950 border border-white/10 px-4 py-3">{["پۆلی ٩","پۆلی ١٠","پۆلی ١١","پۆلی ١٢"].map(x=><option key={x}>{x}</option>)}</select>
 {error&&<p className="text-red-300 text-sm">{error}</p>}<button className="w-full rounded-xl bg-blue-600 py-3 font-bold">دەستپێکردن</button>
 </form></main><Footer/></div>
}