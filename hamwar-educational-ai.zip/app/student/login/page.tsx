 "use client";
import {useState} from "react"; import {useRouter} from "next/navigation";
import Header from "@/components/Header"; import Footer from "@/components/Footer";
export default function Login(){
 const [code,setCode]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError("");
  const r=await fetch("/api/student/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});
  const d=await r.json(); setBusy(false); if(!r.ok){setError(d.error||"کێشەیەک ڕوویدا");return}
  router.push(d.onboarded?"/student/chat":"/student/onboarding");
 }
 return <div className="min-h-screen gradient flex flex-col"><Header/><main className="flex-1 flex items-center justify-center p-5"><form onSubmit={submit} className="glass rounded-3xl p-7 w-full max-w-md">
  <h1 className="text-2xl font-bold mb-2">چوونەژوورەوەی قوتابی</h1><p className="text-slate-400 mb-6">کۆدی چوونەژوورەوەکەت بنووسە.</p>
  <input value={code} onChange={e=>setCode(e.target.value)} placeholder="KOBIR-XXXX-XXXX" className="w-full rounded-xl bg-slate-950 border border-white/10 px-4 py-3 outline-none focus:border-blue-500" required/>
  {error&&<p className="text-red-300 text-sm mt-3">{error}</p>}
  <button disabled={busy} className="mt-5 w-full rounded-xl bg-blue-600 py-3 font-bold disabled:opacity-50">{busy?"چاوەڕێ بکە...":"چوونەژوورەوە"}</button>
 </form></main><Footer/></div>
}