import crypto from "crypto";
export function hashCode(code:string){return crypto.createHash("sha256").update(code.trim().toUpperCase()).digest("hex")}
export function randomCode(){return "KOBIR-"+crypto.randomBytes(3).toString("hex").toUpperCase()+"-"+crypto.randomBytes(2).toString("hex").toUpperCase()}
export function signSession(data:string){return crypto.createHmac("sha256",process.env.SESSION_SECRET!).update(data).digest("hex")}
export function makeToken(role:"admin"|"student",id:string){const p=Buffer.from(JSON.stringify({role,id,exp:Date.now()+1000*60*60*12})).toString("base64url");return p+"."+signSession(p)}
export function readToken(token:string|undefined){if(!token)return null;const [p,s]=token.split(".");if(!p||!s||s!==signSession(p))return null;try{const x=JSON.parse(Buffer.from(p,"base64url").toString());if(x.exp<Date.now())return null;return x}catch{return null}}