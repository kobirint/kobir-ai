# پەیمانگای کۆبیر — Hamwar Educational AI

## 1) دامەزراندن
```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2) Supabase
لە Supabase project ـەکەت، فایل `supabase/migrations/001_initial.sql` جێبەجێ بکە.

## 3) Environment variables
لە `.env.local`:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
- SUPABASE_SECRET_KEY
- GEMINI_API_KEY
- MASTER_ADMIN_CODE
- SESSION_SECRET

`SUPABASE_SECRET_KEY`, `GEMINI_API_KEY`, `MASTER_ADMIN_CODE`, `SESSION_SECRET` تەنها server-side بن.

## 4) Admin
بچۆ `/admin/login` و Master Admin Code ـەکەت بەکاربهێنە.
کۆدی قوتابی لە dashboard دروست دەکرێت.

## 5) Student
قوتابی `/student/login` دەکات، کۆدەکەی دەنووسێت، و تەنها یەکجار onboarding پڕ دەکات.

## 6) Deploy
GitHub ـەکەت پەیوەندی بە Vercel بکە و environment variables ـەکان زیاد بکە.
